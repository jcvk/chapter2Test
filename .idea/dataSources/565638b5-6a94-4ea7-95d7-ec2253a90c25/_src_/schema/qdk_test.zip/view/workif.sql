CREATE VIEW workif AS
  SELECT
    `qdk_test`.`workinfo`.`id`   AS `编号`,
    `qdk_test`.`workinfo`.`name` AS `职位名称`
  FROM `qdk_test`.`workinfo`;
